let clients = [
    { nome: "Lucas Moura", cpf: "000.000.000-00", email: "lucas@exemplo.com" },
    { nome: "Maria Silva", cpf: "111.111.111-11", email: "maria@exemplo.com" },
    { nome: "João Pereira", cpf: "222.222.222-22", email: "joao@exemplo.com" }
];

function populateTable() {
    const tableBody = document.getElementById('client-table-body');
    tableBody.innerHTML = '';

    clients.forEach((client, index) => {
        const row = document.createElement('tr');

        row.innerHTML = `
            <td>${client.nome}</td>
            <td>${client.cpf}</td>
            <td>${client.email}</td>
            <td>
                <a href="atualizarCliente.html" class="btn-edit"><i class="fas fa-pencil-alt"></i></a>
                <button class="btn-delete" data-index="${index}"><i class="fas fa-trash"></i></button>
            </td>
        `;
        tableBody.appendChild(row);
    });

   
    document.querySelectorAll('.btn-delete').forEach(button => {
        button.addEventListener('click', deleteClient);
    });
}

function deleteClient(event) {
    const clientIndex = event.target.closest('button').getAttribute('data-index');
    clients.splice(clientIndex, 1); 
    populateTable(); 
}


populateTable();